"""Platform-specific functions/support for the xorg/X11 windowing system"""
from OpenGL.raw.GLX import *
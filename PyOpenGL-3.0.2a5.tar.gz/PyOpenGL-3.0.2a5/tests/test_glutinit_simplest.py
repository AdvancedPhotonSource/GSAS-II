from OpenGL.GLUT import *
glutInit()
glutInitDisplayMode(GLUT_RGB)
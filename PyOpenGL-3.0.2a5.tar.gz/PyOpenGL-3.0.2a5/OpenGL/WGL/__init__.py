from OpenGL.raw.WGL import *

wglUseFontBitmaps = wglUseFontBitmapsW

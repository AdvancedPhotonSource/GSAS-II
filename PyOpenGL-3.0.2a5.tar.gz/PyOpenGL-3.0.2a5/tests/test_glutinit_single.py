from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
glutInit([''])
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB)